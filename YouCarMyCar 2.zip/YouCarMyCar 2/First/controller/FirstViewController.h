//
//  FirstViewController.h
//  YoucarMycar
//
//  Created by LLY on 15-6-26.
//  Copyright (c) 2015年 LLY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController
@property (nonatomic ,strong)UIScrollView *myscrollView;
@property (nonatomic ,strong)UISegmentedControl *mySegment;

@end
