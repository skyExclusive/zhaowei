//
//  ListFirstTableViewCell.m
//  YouCarMyCar
//
//  Created by LLY on 15/7/1.
//  Copyright (c) 2015年 LLY. All rights reserved.
//

#import "ListFirstTableViewCell.h"

@implementation ListFirstTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
