//
//  CollectionCell.h
//  YouCarMyCar
//
//  Created by ZhaoWei on 15/7/1.
//  Copyright (c) 2015年 LLY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionCell : UICollectionViewCell
@property (nonatomic,strong)UILabel *mylabel;
@property (nonatomic,strong)UIImageView *myimageView;
@end
